<?php
	// -- define site URL
	const BASEURL = 'http://192.168.64.3/speed-volunteer/';
	const SITE_TITLE = 'Project';
?>